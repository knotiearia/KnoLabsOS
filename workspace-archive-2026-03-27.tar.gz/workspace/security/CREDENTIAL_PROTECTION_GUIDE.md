# 🔐 Credential Protection Guide - Knolabs AI Agency

**Version:** 1.0  
**Authority:** [VAULT_PROTOCOL.md](./VAULT_PROTOCOL.md)  
**Owner:** FLUX (Operations Agent)  
**Last Updated:** 2026-03-27  
**Classification:** INTERNAL - Agency Staff Only

---

## 📋 Executive Summary

This guide establishes secure credential management practices for Knolabs AI Agency. All secrets MUST be stored in Vaultwarden (Bitwarden) and retrieved at runtime. **No exceptions.**

### Hard Rules (VIOLATION = SECURITY INCIDENT)

| Rule | Rationale |
|------|-----------|
| 🔴 **NO secrets in code** | Git history is forever |
| 🔴 **NO secrets in .env files** | World-readable by default |
| 🔴 **NO secrets in chat logs** | Telegram retains everything |
| 🔴 **NO secrets in agent memory** | Persistence = exposure |
| 🟡 **Rotate every 90 days** | Limit blast radius |
| 🟢 **Vaultwarden ONLY** | Centralized, auditable, revocable |

---

## 1. File Permission Standards

### Credential File Permissions

```
Recommended: 600 (rw-------)
Maximum:     600
Minimum:     640 (rw-r-----) ONLY for service accounts
Never:       644 (rw-r--r--) or 777
```

### File Type Reference

| File Type | Permission | Owner | Group | Notes |
|-----------|------------|-------|-------|-------|
| `.env` | ❌ **DO NOT USE** | - | - | Use vault instead |
| `.env.example` | 644 | user | user | Template with fake values only |
| `/tmp/.bw_session` | 600 | user | user | Already protected by BW CLI |
| SSH keys | 600 | user | user | Standard practice |
| Service account JSON | 600 | root | root | If absolutely necessary |
| Config files | 640 | user | user-group | No credentials in config |

### Immediate Permission Audit Commands

```bash
# Find world-readable files that might contain secrets
find /workspace -type f -perm -o=r \( \
  -name "*.env" -o \
  -name "*.key" -o \
  -name "*.pem" -o \
  -name "*secret*" -o \
  -name "*credential*" -o \
  -name "*password*" \
) 2>/dev/null

# Fix permissions if found
chmod 600 /path/to/exposed/file

# Verify fix
ls -la /path/to/exposed/file
```

### .env Files: Avoid or Encrypt?

**Answer: AVOID ENTIRELY**

`.env` files are fundamentally insecure:
- Default umask makes them world-readable
- Often accidentally committed to Git
- Copied to logs, backups, Docker layers
- Visible in process listings (`ps e`)

**If you MUST use .env (legacy only):**
```bash
# 1. Set strict permissions immediately
touch .env
chmod 600 .env

# 2. Add to .gitignore BEFORE creating
echo ".env" >> .gitignore
echo ".env.*" >> .gitignore
echo "*.key" >> .gitignore
echo "*.pem" >> .gitignore

# 3. Never export from .env to shell environment
# BAD:  source .env  
# GOOD: Use vault retrieval (see Section 2)
```

---

## 2. Runtime Credential Access

### The BW_SESSION Pattern

**Principle:** Authenticate once, use session token, never store passwords.

```bash
# ═══════════════════════════════════════════════════════════════
# STEP 1: Unlock Vault (One-time per session)
# ═══════════════════════════════════════════════════════════════
export BW_SESSION=$(bw unlock --raw)
# Or use cached session
cat /tmp/.bw_session
export BW_SESSION=$(cat /tmp/.bw_session)

# ═══════════════════════════════════════════════════════════════
# STEP 2: Retrieve Credentials (Runtime Only)
# ═══════════════════════════════════════════════════════════════

# Get password/secret
deepgram_api_key=$(bw get password "Deepgram API Key")
plane_api_key=$(bw get password "Plane.so API Key")
redis_password=$(bw get password "Redis - Knolabs Production")

# Get full item details
github_pat=$(bw get item "GitHub PAT - Knolabs" | jq -r '.login.password')

# ═══════════════════════════════════════════════════════════════
# STEP 3: Use Credentials (In-memory only)
# ═══════════════════════════════════════════════════════════════
export DEEPGRAM_API_KEY="$deepgram_api_key"
export PLANE_API_KEY="$plane_api_key"
export REDIS_PASSWORD="$redis_password"

# Run your application
npm start

# ═══════════════════════════════════════════════════════════════
# STEP 4: Cleanup (Critical)
# ═══════════════════════════════════════════════════════════════
unset deepgram_api_key
unset plane_api_key
unset redis_password
unset DEEPGRAM_API_KEY
unset PLANE_API_KEY
unset REDIS_PASSWORD
```

### Agent Credential Retrieval (Best Practice)

**For Node.js/Python scripts:**

```javascript
// secure-vault.js - Vault retrieval helper
const { execSync } = require('child_process');

function getVaultSecret(itemName, field = 'password') {
  try {
    const bwSession = process.env.BW_SESSION || 
                      require('fs').readFileSync('/tmp/.bw_session', 'utf8').trim();
    
    const result = execSync(`bw get ${field} "${itemName}"`, {
      env: { ...process.env, BW_SESSION: bwSession },
      encoding: 'utf8'
    });
    
    return result.trim();
  } catch (err) {
    throw new Error(`Failed to retrieve ${itemName}: ${err.message}`);
  }
}

// Usage in application
const config = {
  deepgramApiKey: getVaultSecret('Deepgram API Key'),
  planeApiKey: getVaultSecret('Plane.so API Key'),
  redis: {
    host: getVaultSecret('Redis - Knolabs Production', 'username'), // or notes
    password: getVaultSecret('Redis - Knolabs Production')
  }
};

module.exports = { getVaultSecret };
```

```python
# secure_vault.py - Python equivalent
import subprocess
import os

def get_vault_secret(item_name, field="password"):
    """Retrieve secret from Bitwarden vault."""
    bw_session = os.environ.get('BW_SESSION')
    if not bw_session:
        with open('/tmp/.bw_session', 'r') as f:
            bw_session = f.read().strip()
    
    result = subprocess.run(
        ['bw', 'get', field, item_name],
        capture_output=True,
        text=True,
        env={**os.environ, 'BW_SESSION': bw_session}
    )
    
    if result.returncode != 0:
        raise RuntimeError(f"Failed to retrieve {item_name}: {result.stderr}")
    
    return result.stdout.strip()

# Usage
DEEPGRAM_API_KEY = get_vault_secret('Deepgram API Key')
PLANE_API_KEY = get_vault_secret('Plane.so API Key')
```

### On-Demand vs. BW_SESSION Environment Variable

| Approach | Pros | Cons | When to Use |
|----------|------|------|-------------|
| **BW_SESSION env var** | Fast, no repeated unlocks | Session expires (30 min) | Long-running processes |
| **On-demand unlock** | Always fresh, secure | Requires password entry | Interactive scripts |
| **Session file read** | Convenient, automated | File must be protected | Daemon/service scripts |

**Recommendation:** Use `BW_SESSION` env var for agents. Agents should read from `/tmp/.bw_session` at startup.

### Service/Daemon Pattern

```bash
#!/bin/bash
# /etc/systemd/system/knolabs-agent.service

[Unit]
Description=Knolabs AI Agent
After=network.target

[Service]
Type=simple
User=knolabs
Group=knolabs
Environment="BW_SESSION_FILE=/var/run/knolabs/.bw_session"
ExecStartPre=/usr/local/bin/vault-auth.sh
ExecStart=/usr/local/bin/agent-start.sh
Restart=always
RestartSec=10

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/run/knolabs

[Install]
WantedBy=multi-user.target
```

```bash
#!/bin/bash
# vault-auth.sh - Pre-start authentication
if [ -f "$BW_SESSION_FILE" ]; then
    export BW_SESSION=$(cat "$BW_SESSION_FILE")
    if bw status | grep -q "locked"; then
        # Session expired, re-authenticate
        rm -f "$BW_SESSION_FILE"
        echo "BW session expired. Manual re-auth required." >&2
        exit 1
    fi
else
    echo "No BW session file. Create with: bw unlock --raw > $BW_SESSION_FILE" >&2
    exit 1
fi
```

---

## 3. Credential Rotation

### Rotation Schedule

| Credential Type | Rotation Frequency | Owner | Method |
|-----------------|-------------------|-------|--------|
| GitHub PATs | **90 days** | Chief (manual) | GitHub Settings → Regenerate |
| API Keys (Deepgram, Plane) | **90 days** or on exposure | Chief | Provider dashboard |
| Service Account Keys | **180 days** | FLUX | Vault rotation + redeploy |
| Database Passwords | **180 days** or on staff change | FLUX | DB admin + vault update |
| SSH Keys | **1 year** or on compromise | FLUX | `ssh-keygen -t ed25519` |
| TLS Certificates | **Auto-renew** (90 days) | FLUX | Let's Encrypt |

### Rotation Procedure

```bash
# ═══════════════════════════════════════════════════════════════
# GitHub PAT Rotation Example
# ═══════════════════════════════════════════════════════════════

# 1. Generate new PAT in GitHub (keep old one active!)
#    GitHub → Settings → Developer settings → Personal access tokens

# 2. Update vault with NEW token
bw get item "GitHub PAT - Knolabs"
# Copy JSON, modify password field, then:
bw edit item $(bw get item "GitHub PAT - Knolabs" | jq -r '.id') < updated_item.json

# 3. Deploy to all services (rolling restart)
systemctl restart knolabs-agent-a
sleep 5
systemctl restart knolabs-agent-b

# 4. Verify new token works
curl -H "Authorization: token $(bw get password 'GitHub PAT - Knolabs')" \
     https://api.github.com/user

# 5. Revoke OLD token in GitHub (only after verification!)
#    GitHub → Settings → Developer settings → Revoke old PAT

# 6. Document rotation in audit log
echo "$(date -Iseconds) GitHub PAT rotated by $(whoami)" >> /var/log/knolabs/auth.log
```

### Audit Trail for Credential Usage

```bash
# Enable vault audit logging
export BW_AUDIT_LOG=/var/log/knolabs/vault-audit.log

# Log all credential access (wrap retrieval function)
log_credential_access() {
    local item="$1"
    local user="$(whoami)"
    local timestamp="$(date -Iseconds)"
    local pid="$$"
    local cmd="$(ps -o comm= -p $PPID)"
    
    echo "{\"time\":\"$timestamp\",\"user\":\"$user\",\"item\":\"$item\",\"pid\":$pid,\"caller\":\"$cmd\"}" \
        >> /var/log/knolabs/credential-access.log
}

# Usage in retrieval function
get_credential() {
    log_credential_access "$1"
    bw get password "$1"
}
```

### Audit Log Monitoring

```bash
# Check for unusual access patterns
tail -f /var/log/knolabs/credential-access.log | jq -r \
    'select(.item | contains("GitHub")) | "\(.time) - \(.user) accessed \(.item)"'

# Alert on multiple failed attempts
grep "Failed" /var/log/knolabs/vault-audit.log | \
    awk '{print $1}' | sort | uniq -c | sort -rn | head -5
```

---

## 4. Exposure Remediation

### Immediate Steps for `/workspace/acc/.env` Exposure

**Severity: CRITICAL**

```bash
# ═══════════════════════════════════════════════════════════════
# STEP 1: IMMEDIATE CONTAINMENT (Do this NOW)
# ═══════════════════════════════════════════════════════════════

# 1.1 Verify the exposure
ls -la /workspace/acc/.env
# Should show: -rw-r--r-- (BAD) or worse

# 1.2 Remove read permissions immediately
chmod 600 /workspace/acc/.env
chown root:root /workspace/acc/.env  # If possible

# 1.3 Check if file is in Git
if [ -d /workspace/acc/.git ]; then
    cd /workspace/acc
    git status | grep -q ".env" && echo "⚠️ .env is tracked in Git!"
    git log --all --source --remotes -- .env | head -5
fi

# ═══════════════════════════════════════════════════════════════
# STEP 2: ASSESS EXPOSURE
# ═══════════════════════════════════════════════════════════════

# 2.1 Check shell history for credential exposure
history | grep -i "plane\|redis\|deepgram\|github" | grep -E "(key|token|password|secret)"

# 2.2 Check log files
grep -r "PLANE_API_KEY\|REDIS_PASSWORD" /var/log/ 2>/dev/null | head -5

# 2.3 Check process environment
ps auxwwwe | grep -E "PLANE|REDIS|DEEPGRAM" | grep -v grep

# 2.4 Check for backups/copies
find /workspace -name "*.env*" -o -name "*backup*" -o -name "*.bak" 2>/dev/null
find /tmp -name "*env*" -o -name "*acc*" 2>/dev/null

# ═══════════════════════════════════════════════════════════════
# STEP 3: ROTATE ALL EXPOSED CREDENTIALS (Non-negotiable)
# ═══════════════════════════════════════════════════════════════

# 3.1 GitHub PAT
# Go to: https://github.com/settings/tokens
# Click on the exposed token → Regenerate
# Update vault: bw edit item "GitHub PAT - Knolabs"

# 3.2 Plane.so API Key
# Go to: https://app.plane.so/ → Settings → API Keys
# Revoke exposed key → Create new key
# Update vault: bw edit item "Plane.so API Key"

# 3.3 Redis Password
# Connect to Redis: redis-cli -h <host> -a <old_password>
# CONFIG SET requirepass "<new_secure_password>"
# Update vault: bw edit item "Redis - Knolabs Production"

# 3.4 Deepgram API Key
# Go to: https://console.deepgram.com/ → Settings → API Keys
# Revoke exposed key → Create new key
# Update vault: bw edit item "Deepgram API Key"

# ═══════════════════════════════════════════════════════════════
# STEP 4: CLEANUP
# ═══════════════════════════════════════════════════════════════

# 4.1 Remove .env file entirely (migrating to vault)
mv /workspace/acc/.env /workspace/acc/.env.EXPOSED.$(date +%Y%m%d)
chmod 000 /workspace/acc/.env.EXPOSED.*

# 4.2 Create template file (no real values)
cat > /workspace/acc/.env.example << 'EOF'
# Copy to .env.local and fill with vault-retrieved values
# DO NOT COMMIT .env.local
DEEPGRAM_API_KEY=your_deepgram_api_key_here
PLANE_API_KEY=your_plane_api_key_here
REDIS_HOST=your_redis_host
REDIS_PASSWORD=your_redis_password
EOF
chmod 644 /workspace/acc/.env.example

# 4.3 Update .gitignore
cat >> /workspace/acc/.gitignore << 'EOF'
# Security: Never commit credentials
.env
.env.local
.env.*.local
*.key
*.pem
*.p12
*.pfx
/tmp/.bw_session
EOF

# 4.4 Clear shell history
history -c && history -w  # Current session
rm -f ~/.bash_history ~/.zsh_history  # Persistent history

# 4.5 Clear logs (if credentials logged)
sudo find /var/log -type f -name "*.log" -exec grep -l "PLANE_API_KEY\|REDIS_PASSWORD" {} \; | \
    xargs -I {} sudo sh -c 'cat /dev/null > "{}"'

# ═══════════════════════════════════════════════════════════════
# STEP 5: POST-INCIDENT ACTIONS
# ═══════════════════════════════════════════════════════════════

# 5.1 Verify rotation worked
curl -H "Authorization: Bearer $(bw get password 'Plane.so API Key')" \
     https://api.plane.so/api/v1/workspaces/

# 5.2 Document incident
cat > /workspace/acc/SECURITY_INCIDENT_$(date +%Y%m%d).md << EOF
# Security Incident Report

**Date:** $(date -Iseconds)
**Type:** Credential exposure
**Affected:** /workspace/acc/.env
**Severity:** CRITICAL
**Status:** RESOLVED

## Timeline
- Detection: $(date -Iseconds)
- Containment: Immediate (chmod 600)
- Rotation: Complete
- Verification: Complete

## Credentials Rotated
- [x] GitHub PAT
- [x] Plane.so API Key
- [x] Redis Password
- [x] Deepgram API Key

## Root Cause
.env file created with default permissions (644)

## Remediation
- Migrated to vault-only credential access
- Removed .env file
- Updated .gitignore
- Cleared shell history

## Lessons Learned
- Never use .env files in production
- Always chmod 600 before writing secrets
- Use vault retrieval instead
EOF
```

### Migration from .env to Vault

```bash
#!/bin/bash
# migrate-to-vault.sh - Migrate .env credentials to vault

ENV_FILE="${1:-.env}"
PREFIX="${2:-Knolabs}"

if [ ! -f "$ENV_FILE" ]; then
    echo "Usage: $0 <.env file> [prefix]"
    exit 1
fi

echo "🔐 Migrating credentials from $ENV_FILE to vault..."

# Read .env file
while IFS='=' read -r key value || [ -n "$key" ]; do
    # Skip comments and empty lines
    [[ "$key" =~ ^#.*$ ]] && continue
    [[ -z "$key" ]] && continue
    
    # Clean key/value
    key=$(echo "$key" | xargs)
    value=$(echo "$value" | xargs | sed -e 's/^"//' -e 's/"$//')
    
    # Skip if already in vault
    if bw list items --search "$key" | jq -e ".[] | select(.name==\"$key\")" > /dev/null 2>&1; then
        echo "  ⚠️  $key already exists in vault, skipping"
        continue
    fi
    
    # Determine item name
    item_name="$key"
    case "$key" in
        *GITHUB*|*GH_*) item_name="GitHub PAT - $PREFIX" ;;
        *PLANE*) item_name="Plane.so API Key" ;;
        *REDIS*) item_name="Redis - $PREFIX Production" ;;
        *DEEPGRAM*) item_name="Deepgram API Key" ;;
    esac
    
    # Create vault item
    echo "  📦 Adding: $item_name"
    bw get template item | jq \
        --arg name "$item_name" \
        --arg pass "$value" \
        '.name=$name | .login={} | .login.password=$pass' | \
        bw encode | bw create item > /dev/null
        
done < "$ENV_FILE"

echo "✅ Migration complete. Verify in vault: bw list items"
echo "⚠️  Now delete $ENV_FILE and rotate all credentials!"
```

---

## 5. Operational Security

### Prevent Credentials in Shell History

```bash
# ═══════════════════════════════════════════════════════════════
# METHOD 1: Space prefix (simplest, per-command)
# ═══════════════════════════════════════════════════════════════
# Add space before command to exclude from history
 export MY_SECRET="value"  # Note the leading space

# ═══════════════════════════════════════════════════════════════
# METHOD 2: HISTCONTROL (recommended for .bashrc/.zshrc)
# ═══════════════════════════════════════════════════════════════
# Don't save duplicates or commands starting with space
export HISTCONTROL=ignorespace:ignoredups
# Or ignore ALL commands with passwords
export HISTIGNORE="*password*:*secret*:*key*:*token*"

# ═══════════════════════════════════════════════════════════════
# METHOD 3: Disable history for sensitive operations
# ═══════════════════════════════════════════════════════════════
set +o history  # Disable
export SECRET=$(bw get password "Secret Item")
set -o history  # Re-enable

# ═══════════════════════════════════════════════════════════════
# METHOD 4: Use read (interactive scripts)
# ═══════════════════════════════════════════════════════════════
read -s -p "Enter API key: " API_KEY
echo ""  # Newline after silent read
export API_KEY
```

### Secure Logging (Mask Sensitive Data)

```javascript
// secure-logger.js - Mask sensitive data in logs
const SENSITIVE_PATTERNS = [
  /[a-zA-Z0-9_-]*(?:api[_-]?key|password|secret|token)["\s]*[:=]["\s]*([a-zA-Z0-9_-]{8,})/gi,
  /bearer\s+([a-zA-Z0-9_-]{20,})/gi,
  /ghp_[a-zA-Z0-9]{36}/gi,  // GitHub PAT
  /sk-[a-zA-Z0-9]{48}/gi,   // Deepgram key pattern
];

function maskSensitiveData(data) {
  let masked = typeof data === 'string' ? data : JSON.stringify(data);
  
  SENSITIVE_PATTERNS.forEach(pattern => {
    masked = masked.replace(pattern, (match, capture) => {
      if (capture) {
        const visible = capture.slice(0, 4);
        const masked = '*'.repeat(capture.length - 4);
        return match.replace(capture, visible + masked);
      }
      return match.slice(0, 8) + '*'.repeat(match.length - 8);
    });
  });
  
  return masked;
}

// Usage
console.log('API Response:', maskSensitiveData(response));
logger.info('Config loaded:', maskSensitiveData(config));
```

```python
# secure_logger.py - Python equivalent
import re
import json
import os

SENSITIVE_PATTERNS = [
    (re.compile(r'(api[_-]?key|password|secret|token)\s*[=:]\s*([\w-]{8,})', re.I), r'\1=\2****'),
    (re.compile(r'(bearer\s+)([\w-]{20,})', re.I), r'\1****'),
    (re.compile(r'ghp_[a-z0-9]{36}', re.I), 'ghp_****'),
    (re.compile(r'sk-[a-z0-9]{48}', re.I), 'sk-****'),
]

def mask_sensitive_data(data):
    """Mask sensitive data in logs."""
    text = data if isinstance(data, str) else json.dumps(data)
    
    for pattern, replacement in SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    
    return text

# Usage
print(f"Config: {mask_sensitive_data(config)}")
```

### Process Visibility (Who Can See Env Vars)

```bash
# ═══════════════════════════════════════════════════════════════
# CHECK: Who can see environment variables?
# ═══════════════════════════════════════════════════════════════

# All processes can see their own env vars (normal)
echo $SECRET

# Root can see ANY process's env vars
sudo cat /proc/<pid>/environ | tr '\0' '\n'

# Same user can see process env via ps
ps auxwwwe | grep <pattern>

# System-wide exposure via /proc
ls -la /proc/*/environ 2>/dev/null | wc -l

# ═══════════════════════════════════════════════════════════════
# MITIGATION: Minimize env var lifetime
# ═══════════════════════════════════════════════════════════════

# BAD: Export to shell, available to all child processes
export API_KEY="secret"
node server.js  # API_KEY visible to node and all children

# GOOD: Pass directly to process only
API_KEY=$(bw get password "API Key") node server.js
# API_KEY only visible to node, not to shell

# BETTER: Use file descriptor or stdin
echo "$(bw get password "API Key")" | node server.js --read-from-stdin

# BEST: Use vault retrieval INSIDE the application
# (see Section 2 code examples)
```

### Process Isolation Checklist

| Check | Command | Expected Result |
|-------|---------|-----------------|
| No secrets in current env | `env \| grep -iE "(key\|token\|secret\|password)"` | Empty output |
| No secrets in process list | `ps auxwwwe \| grep -iE "(key\|token\|secret)"` | Empty output |
| Shell history clean | `history \| grep -iE "(key\|token\|secret)"` | Empty output |
| No credential files readable | `find ~ -perm -o=r -name "*.env" 2>/dev/null` | Empty output |
| Vault session secured | `ls -la /tmp/.bw_session` | `-rw-------` |

---

## 6. Standard Operating Procedure (SOP)

### Adding New Credentials

```bash
# ═══════════════════════════════════════════════════════════════
# SOP-001: Adding a New Secret to Knolabs Infrastructure
# ═══════════════════════════════════════════════════════════════

# PREREQUISITES:
# - Vault access (bw login status: unlocked)
# - Chief approval for new service credentials

# STEP 1: Verify secret doesn't exist
bw list items --search "Service Name" | jq '.[].name'

# STEP 2: Create vault item
bw get template item | jq \
    --arg name "Service - Environment" \
    --arg user "service_username" \
    --arg pass "service_password_or_key" \
    --arg notes "Service: https://service.com
API Docs: https://docs.service.com
Contact: support@service.com
Purpose: Brief description of use" \
    '.name=$name | .login={} | .login.username=$user | .login.password=$pass | .notes=$notes' | \
    bw encode | bw create item

# STEP 3: Verify creation
bw get item "Service - Environment"

# STEP 4: Test credential works
export TEMP_KEY=$(bw get password "Service - Environment")
curl -H "Authorization: Bearer $TEMP_KEY" https://api.service.com/verify
unset TEMP_KEY

# STEP 5: Document in service registry
echo "- Service: $(date -I) | Service - Environment | Owner: $(whoami)" \
    >> /workspace/docs/SERVICE_REGISTRY.md

# STEP 6: NEVER store elsewhere
# ✗ No .env file
# ✗ No config file
# ✗ No chat message
# ✗ No email
```

### Credential Access SOP

```bash
# ═══════════════════════════════════════════════════════════════
# SOP-002: Accessing Credentials for Agent/Task Use
# ═══════════════════════════════════════════════════════════════

# STEP 1: Ensure vault session
if ! bw status | grep -q "unlocked"; then
    export BW_SESSION=$(cat /tmp/.bw_session 2>/dev/null || bw unlock --raw)
fi

# STEP 2: Retrieve credential
CREDENTIAL=$(bw get password "Item Name")

# STEP 3: Use immediately
some_command --api-key "$CREDENTIAL"

# STEP 4: Immediate cleanup
unset CREDENTIAL

# STEP 5: Log access (automated in wrapper functions)
```

### Incident Response SOP

```
┌────────────────────────────────────────────────────────────────┐
│              CREDENTIAL EXPOSURE RESPONSE FLOW                  │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐                                               │
│  │  DETECTED   │ ◄── File perms wrong, committed to Git,     │
│  │   EXPOSURE  │     logged to disk, seen in process list    │
│  └──────┬──────┘                                               │
│         │                                                       │
│         ▼                                                       │
│  ┌─────────────┐     NO         ┌─────────────┐               │
│  │ In Git      │───────────────►│ In logs     │               │
│  │ history?    │                │ or process? │               │
│  └──────┬──────┘                └──────┬──────┘               │
│         │ YES                          │ YES                   │
│         ▼                               ▼                       │
│  ┌─────────────┐                ┌─────────────┐               │
│  │ IMMEDIATE   │                │ Clear logs  │               │
│  │ ROTATION    │                │ Clear env   │               │
│  │ (no choice) │                │ Clear hist  │               │
│  └──────┬──────┘                └──────┬──────┘               │
│         │                               │                       │
│         └─────────────┬─────────────────┘                       │
│                       ▼                                         │
│              ┌─────────────┐                                   │
│              │ chmod 600   │                                   │
│              │ remove from │                                   │
│              │ production  │                                   │
│              └──────┬──────┘                                   │
│                     │                                           │
│                     ▼                                           │
│              ┌─────────────┐                                   │
│              │ ROTATE ALL  │ ◄── Non-negotiable               │
│              │ CREDENTIALS │     in .env file                 │
│              └──────┬──────┘                                   │
│                     │                                           │
│                     ▼                                           │
│              ┌─────────────┐                                   │
│              │ VERIFY      │                                   │
│              │ SERVICES    │                                   │
│              └──────┬──────┘                                   │
│                     │                                           │
│                     ▼                                           │
│              ┌─────────────┐                                   │
│              │ DOCUMENT    │                                   │
│              │ INCIDENT    │                                   │
│              └─────────────┘                                   │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

---

## 7. Quick Reference

### One-Liner Security Checks

```bash
# Daily security audit
alias security-check='
  echo "=== File Permissions ===" && \
  find /workspace -type f \( -name "*.env" -o -name "*.key" \) -perm /o=r 2>/dev/null && \
  echo "=== Shell History ===" && \
  history | grep -iE "(key|token|secret|password)" | wc -l && \
  echo "=== Vault Status ===" && \
  bw status | jq -r ".status" && \
  echo "=== Process Secrets ===" && \
  ps auxwwwe | grep -cE "(PLANE|REDIS|DEEPGRAM|GITHUB)"
'

# Run it
security-check
```

### Emergency Contacts

| Role | Contact | For |
|------|---------|-----|
| Chief | Telegram 8445026451 | Approval, incidents |
| Aria | N/A (me) | Orchestration |
| FLUX | This guide | Operations, rotation |
| Vault Admin | Chief | Access issues |

---

## Appendices

### A. Vault Item Naming Convention

```
Format: [Service] - [Environment] - [Purpose]

Examples:
✓ "GitHub PAT - Knolabs Production"
✓ "Plane.so API Key"
✓ "Redis - Knolabs Production"
✓ "Deepgram API Key"
✓ "AWS - Knolabs - S3 Access"

Avoid:
✗ "key1"
✗ "test"
✗ "github"
✗ "api_key_final_FINAL"
```

### B. Credential Strength Requirements

| Type | Minimum Length | Requirements |
|------|---------------|--------------|
| API Keys | 32 chars | Random, no dictionary words |
| Passwords | 16 chars | Mixed case + numbers + symbols |
| Tokens | 40 chars | Provider-generated only |
| Encryption keys | 256 bits | `openssl rand -base64 32` |

### C. Related Documents

- [VAULT_PROTOCOL.md](./VAULT_PROTOCOL.md) - Vault access quick reference
- `/workspace/docs/SERVICE_REGISTRY.md` - Service inventory
- `/var/log/knolabs/credential-access.log` - Access audit trail

---

**Document Owner:** FLUX (Operations Agent)  
**Review Schedule:** Quarterly or after security incident  
**Next Review:** 2026-06-27  
**Distribution:** Knolabs AI Agency - Internal Only 🔐
