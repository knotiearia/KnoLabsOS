# 🔐 Vault Access Pattern - Security Guidelines

**Last Updated:** 2026-03-27  
**Classification:** INTERNAL - Security Critical  
**Owner:** Aria (Chief Orchestrator)

---

## 🚨 CRITICAL: NEVER Store in Chat, Files, or Git

The following items must **NEVER** be stored in:
- ❌ Chat messages (Telegram, Slack, etc.)
- ❌ Markdown files (.md)
- ❌ Text files (.txt)
- ❌ Configuration files
- ❌ Git repositories
- ❌ Environment files (.env)
- ❌ Log files

### Prohibited Items:

| Item | Example Pattern | Risk Level |
|------|----------------|------------|
| Vault password | `myVaultPassword123!` | 🔴 CRITICAL |
| BW_SESSION value | `BW_SESSION=abc123...` | 🔴 CRITICAL |
| GitHub PATs | `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` | 🔴 CRITICAL |
| Plane API tokens | `plane_api_xxxxxxxxxxxxxxxxxxxxxxxx` | 🔴 CRITICAL |
| AWS access keys | `AKIAIOSFODNN7EXAMPLE` | 🔴 CRITICAL |
| Database passwords | `postgres://user:PASS@host` | 🔴 CRITICAL |
| Private keys | `-----BEGIN RSA PRIVATE KEY-----` | 🔴 CRITICAL |
| JWT tokens | `eyJhbGciOiJIUzI1NiIs...` | 🟠 HIGH |

---

## ✅ CORRECT: Vault Access Pattern

### Runtime Retrieval Only

```bash
# Aria retrieves from vault at runtime - NEVER hardcode
export BW_SESSION=$(cat /tmp/.bw_session)
bw get item "Item Name" --raw
```

### In Scripts

```bash
#!/bin/bash
# Get session from secure location (not in script!)
BW_SESSION_FILE="/tmp/.bw_session"

if [ -f "$BW_SESSION_FILE" ]; then
    export BW_SESSION=$(cat "$BW_SESSION_FILE")
    PLANE_TOKEN=$(bw get password "Plane.so API Token")
    GH_TOKEN=$(bw get password "GitHub PAT")
else
    echo "ERROR: Vault session not available"
    exit 1
fi
```

### In Applications

```javascript
// Never do this:
const API_KEY = "[EXAMPLE-API-KEY]";  // ❌ WRONG

// Do this instead:
const API_KEY = process.env.PLANE_API_TOKEN;  // ✅ CORRECT
// Load from vault at startup, store in memory only
```

---

## 🔧 Aria's Memorized Vault Configuration

| Setting | Value | Status |
|---------|-------|--------|
| Session file | `/tmp/.bw_session` | ✅ Exists |
| CLI tool | `bw` (Bitwarden CLI) | ✅ Installed |
| Vault server | `https://vault.kno2gether.com` | ✅ Active |
| Authentication | Session-based | ✅ Configured |

### Session File Security

- **Location:** `/tmp/.bw_session`
- **Permissions:** 600 (owner read/write only)
- **Lifetime:** Session-based, expires after inactivity
- **Backup:** Never - recreated on each vault unlock

---

## 📝 Secret Reference Pattern

When you need to reference a secret in documentation, use this format:

```markdown
# Instead of:
API Key: ghp_abc123def456ghi789jkl012mno345pqr678stu

# Use:
API Key: [RETRIEVE_FROM_VAULT:GitHub PAT]
# Or
API Key: See Bitwarden: "GitHub PAT"
```

---

## 🔄 Credential Rotation Schedule

| Credential Type | Rotation Frequency | Last Rotated | Next Rotation |
|----------------|-------------------|--------------|---------------|
| Vault Master Password | Immediate + Quarterly | 2026-03-27 | 2026-06-27 |
| GitHub PATs | Quarterly | TBD | TBD |
| Plane API Tokens | Quarterly | TBD | TBD |
| AWS Keys | Quarterly | TBD | TBD |

---

## 🚨 Emergency: Credential Exposure Response

### If credentials were exposed:

1. **IMMEDIATE (within 5 minutes):**
   ```bash
   # Run secret scan to identify exposure
   /root/.openclaw/workspace/cron/jobs/secret-scan.sh
   ```

2. **QUARANTINE (within 10 minutes):**
   - Check `/root/.openclaw/workspace/security/quarantine/`
   - Review exposed files

3. **ROTATE (within 30 minutes):**
   - Rotate vault master password immediately
   - Rotate any exposed API tokens
   - Regenerate all GitHub PATs
   - Update AWS keys

4. **CLEANUP (within 1 hour):**
   ```bash
   # Remove from git history if committed
   git filter-repo --path <file-with-secret> --invert-paths
   # Or use BFG Repo-Cleaner for large repos
   ```

5. **VERIFY:**
   - Re-run secret scan
   - Check git log for any remaining traces
   - Audit all systems that used exposed credentials

---

## 🛡️ Security Controls

### Automated Protections:

1. **Pre-Commit Hook:** `.git/hooks/pre-commit`
   - Blocks commits with secrets
   - Runs on every `git commit`

2. **Secret Scanner:** `/root/.openclaw/workspace/cron/jobs/secret-scan.sh`
   - Daily full workspace scan
   - Quarantines files with secrets
   - Alerts Chief immediately

3. **Nightly Cleanup:** `/root/.openclaw/workspace/cron/jobs/nightly-cleanup.sh`
   - Scans before any backup
   - Quarantines suspicious files
   - Reports findings

### Manual Verification:

```bash
# Run secret scan manually
/root/.openclaw/workspace/cron/jobs/secret-scan.sh

# Check quarantine directory
ls -la /root/.openclaw/workspace/security/quarantine/

# View recent alerts
tail -50 /root/.openclaw/workspace/cron/logs/security/secret-alerts-$(date +%Y%m%d).log
```

---

## 📞 Contact

**Security Issues:** Contact Chief immediately  
**Vault Access Issues:** Aria (via this interface)  
**False Positives:** Document in security logs

---

## ⚠️ REMINDER

> **NEVER type credentials in chat.**  
> **NEVER commit credentials to git.**  
> **NEVER store credentials in files.**  
>  
> **ALWAYS retrieve from vault at runtime.**

**Violation of these policies compromises the entire agency's security.**

---

*This document is automatically updated when security policies change.*
es change.*
