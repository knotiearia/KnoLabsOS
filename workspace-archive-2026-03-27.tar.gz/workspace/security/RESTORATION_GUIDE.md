# 🔐 Restoration Guide - Disaster Recovery Procedures

**Document:** RESTORATION_GUIDE.md  
**Version:** 1.0  
**Last Updated:** 2026-03-27  
**Owner:** Aria (Chief Orchestrator)  

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Emergency Contacts](#emergency-contacts)
3. [Scenario 1: VPS Complete Failure](#scenario-1-vps-complete-failure)
4. [Scenario 2: Partial Data Loss](#scenario-2-partial-data-loss)
5. [Scenario 3: Vault Session Expiration](#scenario-3-vault-session-expiration)
6. [Scenario 4: Credential Compromise](#scenario-4-credential-compromise)
7. [Pre-Recovery Checklist](#pre-recovery-checklist)
8. [Post-Recovery Verification](#post-recovery-verification)

---

## Overview

This guide provides step-by-step procedures for recovering the Knolabs AI Agency infrastructure in various disaster scenarios.

### Backup Locations

| Type | Location | Retention |
|------|----------|-----------|
| Local Archive | `/root/.backups/workspace_backup_*.tar.gz` | 30 days |
| Git Repository | Configured via `BACKUP_REPO` env var | Indefinite |
| Vault Secrets | Vaultwarden server (https://vault.kno2gether.com) | Persistent |

### Critical Assets

| Asset | Recovery Priority | Storage |
|-------|------------------|---------|
| Agent configurations | 🔴 Critical | Backup archive |
| Workspace files | 🔴 Critical | Backup archive |
| Vault credentials | 🔴 Critical | Vaultwarden (external) |
| GitHub PAT | 🟠 High | Vaultwarden |
| Plane.so API token | 🟠 High | Vaultwarden |
| Redis passwords | 🟠 High | Vaultwarden |

---

## Emergency Contacts

| Role | Contact Method |
|------|---------------|
| Chief (Avijit Clawed) | Telegram: @avijit_blogs |
| Vault Admin | Chief only |
| VPS Provider | Alibaba Cloud Console |

---

## Scenario 1: VPS Complete Failure

**Indication:** VPS unreachable, instance terminated, or hardware failure

### Step 1: Provision New VPS

1. **Create new instance** (Alibaba Cloud)
   - Recommended: Same region as original
   - Minimum specs: 2 vCPU, 8GB RAM, 40GB disk
   - OS: Ubuntu 24.04 LTS

2. **Configure SSH access**
   ```bash
   # On new VPS, add Chief's public key
   mkdir -p ~/.ssh
   echo "ssh-ed25519 AAAAC3NzaC..." >> ~/.ssh/authorized_keys
   chmod 600 ~/.ssh/authorized_keys
   ```

### Step 2: Restore from Backup

1. **Install dependencies**
   ```bash
   apt update && apt upgrade -y
   apt install -y curl wget git nodejs npm docker.io docker-compose
   ```

2. **Download latest backup**
   ```bash
   # If backup is on external storage (S3, etc.)
   # aws s3 cp s3://your-bucket/latest-backup.tar.gz /tmp/
   
   # If backup was transferred manually
   # scp user@backup-server:/backups/workspace_backup_*.tar.gz /tmp/
   ```

3. **Extract backup**
   ```bash
   mkdir -p /root/.openclaw/workspace
   tar -xzf workspace_backup_*.tar.gz -C /root/.openclaw/
   ```

### Step 3: Re-Authenticate with Vault

⚠️ **CRITICAL:** The BW_SESSION at `/tmp/.bw_session` is NOT backed up (intentionally). You must re-authenticate.

1. **Install Bitwarden CLI**
   ```bash
   npm install -g @bitwarden/cli
   ```

2. **Chief: Login to Vaultwarden**
   ```bash
   # Chief runs this manually - NEVER automate the password
   export BW_SESSION=$(bw login knotiearia@gmail.com --raw)
   
   # Save session for Aria to use
   echo "$BW_SESSION" > /tmp/.bw_session
   chmod 600 /tmp/.bw_session
   ```

3. **Verify vault access**
   ```bash
   bw sync
   bw list items | head -5
   ```

### Step 4: Restore Runtime Secrets

1. **Restore ACC .env file**
   ```bash
   # Retrieve secrets from vault
   PLANE_API_KEY=$(bw get password "Plane.so API Token")
   
   # Create .env file
   cat > /workspace/acc/.env << EOF
   export PLANE_API_KEY="$PLANE_API_KEY"
   export PLANE_WORKSPACE_SLUG="knolabs"
   export PLANE_API_BASE_URL="https://flights.kno2gether.com"
   export REDIS_URL="redis://127.0.0.1:6379"
   export ACC_DIR="/workspace/acc"
   export ACC_API_PORT="3001"
   EOF
   
   chmod 600 /workspace/acc/.env
   ```

2. **Restore GitHub credentials** (if needed)
   ```bash
   GH_TOKEN=$(bw get password "GitHub PAT")
   export GITHUB_TOKEN="$GH_TOKEN"
   ```

### Step 5: Restart Services

```bash
# Start OpenClaw Gateway
sudo systemctl start openclaw-gateway

# Start ACC API (if using systemd)
sudo systemctl start acc-api

# Start Docker containers
cd /root/.openclaw/workspace
docker-compose up -d  # If applicable
```

---

## Scenario 2: Partial Data Loss

**Indication:** Some files deleted or corrupted, but VPS is operational

### Recovery Steps

1. **Identify what's missing**
   ```bash
   # Run secret scan to check current state
   /root/.openclaw/workspace/security/secret-scanner.sh --verbose
   ```

2. **Restore from latest backup**
   ```bash
   # Find latest backup
   LATEST=$(ls -t /root/.backups/workspace_backup_*.tar.gz | head -1)
   
   # Extract to temporary location
   mkdir -p /tmp/restore
   tar -xzf "$LATEST" -C /tmp/restore
   
   # Copy specific missing files
   cp /tmp/restore/agents/pixel/IDENTITY.md /root/.openclaw/workspace/agents/pixel/
   # (repeat for other missing files)
   ```

3. **Verify restoration**
   ```bash
   # Check file integrity
   ls -la /root/.openclaw/workspace/agents/
   
   # Re-run secret scan
   /root/.openclaw/workspace/security/secret-scanner.sh
   ```

---

## Scenario 3: Vault Session Expiration

**Indication:** Aria reports "BW_SESSION not found" or vault commands fail

### Understanding BW_SESSION

- **Location:** `/tmp/.bw_session`
- **Format:** Random token string
- **Lifetime:** ~1 hour of inactivity (Bitwarden default)
- **Security:** Never backed up, must be recreated

### Recovery Steps

1. **Aria detects session expiration**
   ```
   "Chief, I need vault access. BW_SESSION has expired."
   ```

2. **Chief re-authenticates**
   ```bash
   # Chief runs in terminal:
   bw login knotiearia@gmail.com
   # OR if already logged in:
   bw unlock
   
   # Save new session
   export BW_SESSION=$(bw unlock --raw)
   echo "$BW_SESSION" > /tmp/.bw_session
   chmod 600 /tmp/.bw_session
   ```

3. **Aria resumes operations**
   - Aria reads `/tmp/.bw_session`
   - Normal vault operations resume

### Prevention

```bash
# Optional: Extend session timeout (Chief only)
# This is done via Bitwarden web UI:
# https://vault.kno2gether.com → Settings → Security → Session Timeout
```

---

## Scenario 4: Credential Compromise

**Indication:** Suspected or confirmed credential exposure

### Immediate Response (First 5 Minutes)

1. **Stop all automated processes**
   ```bash
   sudo systemctl stop openclaw-gateway
   sudo systemctl stop acc-api
   ```

2. **Revoke exposed credentials**
   - GitHub: https://github.com/settings/tokens → Delete exposed PAT
   - Plane.so: Workspace Settings → API Tokens → Regenerate

### Rotation Procedure

1. **Rotate Vault Master Password**
   ```bash
   # Chief logs into Vaultwarden web UI
   # Settings → My Account → Master Password
   ```

2. **Generate New GitHub PAT**
   - GitHub → Settings → Developer Settings → Personal Access Tokens
   - Generate new token with same permissions
   - Save to vault: `bw create password "GitHub PAT"`

3. **Generate New Plane.so API Token**
   - Plane.so → Settings → API Tokens
   - Create new token
   - Save to vault: `bw create password "Plane.so API Token"`

4. **Update all .env files**
   ```bash
   # Retrieve new secrets
   NEW_PLANE_KEY=$(bw get password "Plane.so API Token")
   
   # Update /workspace/acc/.env
   sed -i "s/PLANE_API_KEY=.*/PLANE_API_KEY=\"$NEW_PLANE_KEY\"/" /workspace/acc/.env
   ```

5. **Restart services**
   ```bash
   sudo systemctl start openclaw-gateway
   sudo systemctl start acc-api
   ```

---

## Pre-Recovery Checklist

Before starting any recovery procedure:

- [ ] Confirm scope of data loss
- [ ] Verify backup integrity (if available)
- [ ] Ensure Chief is available for vault re-authentication
- [ ] Document all changes during recovery
- [ ] Have emergency contacts ready

---

## Post-Recovery Verification

After any recovery:

1. **Run full secret scan**
   ```bash
   /root/.openclaw/workspace/security/secret-scanner.sh --verbose
   ```

2. **Verify vault access**
   ```bash
   bw sync
   bw list items | wc -l  # Should show expected count
   ```

3. **Test service connectivity**
   ```bash
   # Test ACC API
curl http://localhost:3001/health

   # Test OpenClaw Gateway
   curl http://localhost:18789/status
   ```

4. **Create new backup**
   ```bash
   /root/.openclaw/workspace/cron/jobs/secure-backup.sh
   ```

5. **Document the incident**
   - What happened
   - Recovery steps taken
   - Lessons learned
   - Prevention measures

---

## Quick Reference Commands

```bash
# Check backup status
cat /root/.openclaw/workspace/cron/logs/backups/.last_backup

# List available backups
ls -la /root/.backups/

# Run secret scan
/root/.openclaw/workspace/security/secret-scanner.sh

# Manual backup
/root/.openclaw/workspace/cron/jobs/secure-backup.sh

# Vault login (Chief only)
export BW_SESSION=$(bw login knotiearia@gmail.com --raw)

# Get secret from vault
bw get password "Item Name"
```

---

## Document History

| Date | Version | Changes |
|------|---------|---------|
| 2026-03-27 | 1.0 | Initial restoration guide |

---

**Remember:** Security is a process, not a product. When in doubt, ask Chief. 🔐
