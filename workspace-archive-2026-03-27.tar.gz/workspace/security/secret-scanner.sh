#!/bin/bash
# =============================================================================
# Secret Scanner - Pre-Backup Security Check
# =============================================================================
# Returns 0 if clean, 1 if secrets found
# Run before any backup operation to ensure no credentials are exposed
#
# Usage: ./secret-scanner.sh [--verbose]
#   --verbose    Show detailed scan output
# =============================================================================

set -euo pipefail

VERBOSE=false
if [[ "${1:-}" == "--verbose" ]]; then
    VERBOSE=true
fi

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Scan targets
SCAN_DIRS=(
    "/root/.openclaw/workspace"
    "/root/.openclaw/memory"
)

# Directories to exclude (documentation/examples)
EXCLUDE_DIRS=(
    "/root/.openclaw/workspace/security"
    "/root/.openclaw/workspace/cron/logs"
)

# Build exclude pattern for find
EXCLUDE_PATTERN=""
for dir in "${EXCLUDE_DIRS[@]}"; do
    EXCLUDE_PATTERN="$EXCLUDE_PATTERN -not -path '$dir/*'"
done

# Secret patterns (regex)
FOUND_SECRETS=0
FOUND_FILES=()

echo "🔍 Starting secret scan..."
echo "=========================="

# Scan each directory
for scan_dir in "${SCAN_DIRS[@]}"; do
    if [[ ! -d "$scan_dir" ]]; then
        $VERBOSE && echo "⚠️  Directory not found: $scan_dir"
        continue
    fi
    
    $VERBOSE && echo "📂 Scanning: $scan_dir"
    
    # Find all matching files with exclusions
    while IFS= read -r -d '' file; do
        # Skip binary files
        if file "$file" | grep -q "binary"; then
            continue
        fi
        
        # Skip the scanner script itself
        if [[ "$(basename "$file")" == "secret-scanner.sh" ]]; then
            continue
        fi
        
        # Skip .env files (they're expected configs, excluded from backup separately)
        if [[ "$(basename "$file")" == ".env" ]] || [[ "$file" == *.env ]]; then
            $VERBOSE && echo "   Skipping .env file: $file"
            continue
        fi
        
        # Check patterns individually
        
        # Pattern 1: Vault email
        if grep -q "knotiearia@gmail\.com" "$file" 2>/dev/null; then
            FOUND_SECRETS=$((FOUND_SECRETS + 1))
            FOUND_FILES+=("$file")
            $VERBOSE && echo "Found knotiearia@gmail.com in $file"
        fi
        
        # Pattern 2: Vault password
        if grep -q "N0thingT0R3m3mb3r" "$file" 2>/dev/null; then
            FOUND_SECRETS=$((FOUND_SECRETS + 1))
            FOUND_FILES+=("$file")
            $VERBOSE && echo "Found vault password in $file"
        fi
        
        # Pattern 3: GitHub PAT (36+ chars after ghp_)
        if grep -qE "ghp_[a-zA-Z0-9]{36,}" "$file" 2>/dev/null; then
            FOUND_SECRETS=$((FOUND_SECRETS + 1))
            FOUND_FILES+=("$file")
            $VERBOSE && echo "Found GitHub PAT in $file"
        fi
        
        # Pattern 4: Plane API key (32 hex chars after plane_api_)
        if grep -qE "plane_api_[a-f0-9]{32}" "$file" 2>/dev/null; then
            FOUND_SECRETS=$((FOUND_SECRETS + 1))
            FOUND_FILES+=("$file")
            $VERBOSE && echo "Found Plane API key in $file"
        fi
        
        # Pattern 5: BW_SESSION token (only in code/config files, not docs)
        if [[ "$file" != *.md ]] && grep -qE "BW_SESSION=[a-zA-Z0-9]{20,}" "$file" 2>/dev/null; then
            FOUND_SECRETS=$((FOUND_SECRETS + 1))
            FOUND_FILES+=("$file")
            $VERBOSE && echo "Found BW_SESSION in $file"
        fi
        
    done < <(eval "find '$scan_dir' -type f \( -name '*.md' -o -name '*.txt' -o -name '*.sh' -o -name '*.json' -o -name '*.log' -o -name '*.env' \) $EXCLUDE_PATTERN -print0 2>/dev/null")
done

# Summary
echo ""
echo "=========================="
if [[ $FOUND_SECRETS -gt 0 ]]; then
    echo -e "${RED}❌ SCAN FAILED: $FOUND_SECRETS secret(s) found${NC}"
    echo ""
    echo "Affected files:"
    printf '%s\n' "${FOUND_FILES[@]}" | sort -u | while read file; do
        echo "  - $file"
    done
    echo ""
    echo "🚨 Backup ABORTED. Fix exposures before proceeding."
    exit 1
else
    echo -e "${GREEN}✅ SCAN PASSED: No secrets detected${NC}"
    echo "🛡️  Safe to proceed with backup."
    exit 0
fi
